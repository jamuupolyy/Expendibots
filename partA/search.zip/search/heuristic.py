import math


def eucledean_distance(a, b):
    '''
    Calculate eucledean distance between two positions.
    :param a: position a
    :param b: position b
    :return: the eucledean distance between a and b.
    '''
    distance = math.sqrt(((a[0]-b[0])**2)+((a[1]-b[1])**2))
    return distance


def group_manhattan_distance(a, b):
    """
    Calculate manhattan distance between two positions for groups.
    :param a: position a
    :param b: position b
    :return: the manhattan distance between a and b.
    """

    x = math.fabs(a[0] - b[0])
    y = math.fabs(a[1] - b[1])
    # detects if white piece is in the corner of goal piece
    if(x == 1 and y == 1):
        return 1
    return x+y


def manhattan_distance(a, b):
    """
    Calculate manhattan distance between two positions.
    :param a: position a
    :param b: position b
    :return: the manhattan distance between a and b.
    """
    return math.fabs(a[0] - b[0]) + math.fabs(a[1] - b[1])


def manhattan_heuristic(board, primary_white_piece, group, intersection_flag):
    """
    Heuristic function to guide search in an appropriate direction.
    :param primary_white_piece:
    :param group:
    :param intersection_flag:
    :return: the manhattan distance between a piece and the intersection or nearest group black stack
    """
    if intersection_flag == 1:
        return manhattan_distance(primary_white_piece, group)

    # Initialise the minimum value to infinity, we aim to improve this
    min_value = math.inf
    goal = None
    for black_stack in group:
        # print(group)
        # Get the co-ordinates of the black stack
        black_stack_position = black_stack[1], black_stack[2]
        # Iterate through each stack of white pieces
        # Calculate the manhattan distance
        distance = eucledean_distance(
            primary_white_piece, black_stack_position)
        # If the calculated manhattan distance is less than the current minimum, replace it.
        if distance < min_value:
            min_value = distance
            goal = black_stack
            goal_pos = black_stack_position

    return group_manhattan_distance(primary_white_piece, goal_pos) - 1
