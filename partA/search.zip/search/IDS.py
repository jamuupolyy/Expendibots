from search.moves import *
from search.entities import *
from search.group import *
import copy

# WE ARE NOT USING THIS ALGORITHM, PLEASE GO TO IDA.PY INSTEAD

# pseudo-code used as reference
# https://www.geeksforgeeks.org/iterative-deepening-searchids-iterative-deepening-depth-first-searchiddfs/


def iddfs_control_loop(board):
    """
    manages threshold on each dfs call
    with `print_board.`
    :param board: contains board data
    """
    found = False
    depth = 0
    while not found:
        print("#DEPTH = + " + str(depth))
        found = iddfs(board, depth, None)
        depth += 1


# pseudo-code used as reference
# https://www.geeksforgeeks.org/iterative-deepening-searchids-iterative-deepening-depth-first-searchiddfs/
def iddfs(board, depth, prev_move):
    board.print()
    check_groups(board)

    # if the goal state is reached, the board is printed and we break out of recursion using the true flag
    if check_goal(board):
        board.print()
        return True

    # returns if the depth gets below 0, the depth range increases on each iteration
    if depth <= 0:
        return False

    # for loop for each
    # iterates through white pieces
    for key in list(board.white_dict):

        # iterates through how many pieces in a stack to move at a time
        for move_index in range(1, board.white_dict[key].count+1):

            # iterates through moves
            for move in MOVES:

                # ensures that a piece doesn't backtrack
                if move != inverse_move[prev_move]:

                    # makes a copy of the current board state and moves the pieces inside
                    move_board = copy.deepcopy(board)
                    # must rework
                    # move_piece(key, move, move_index, move_board,
                    #           move_board.white_dict[key].count)

                    # calls the next recursion level using the new board
                    if iddfs(move_board, depth - 1, move):
                        return True
