"""
COMP30024
Artificial Intelligence
Members:
Deevesh Shanmuganathan
Jason Polychronopoulos
Group: AlbanianRodentDinner
"""

import json
import time
from search.IDA import *
from search.IDS import *


def print_commands(commands):
    """
    Print commands
    :param commands: list of commands
    """
    for i in commands:
        print(i)


def solve_groups(board):
    """
    Solves groups
    :param board: board data
    """
    assignment = assign_pieces(board)
    while (board.group_set != [] and len(assignment) != 0):
        primary_piece = assignment[0][0]
        group = assignment[0][1]
        ida_star_control_loop(board, primary_piece, group, 0)
        assignment = assign_pieces(board)


def solve_bridges(board):
    """
    Solves bridges
    :param board: board data
    """
    bridges = find_bridges(board.group_set)

    while (board.group_set != [] and len(bridges) != 0):
        primary_piece, bridge = assign_bridges(board, list(bridges))
        if primary_piece == False:
            break
        ida_star_control_loop(board, primary_piece, bridge, 1)
        bridges = find_bridges(board.group_set)


def main():
    # intitialises a timer to track solve time
    start_time = time.time()

    # Initialise the board
    board = Board()

    # Load data from .json into
    with open(sys.argv[1]) as file:
        data = json.load(file)

    # returns a set of pieces containing groups that will explode if a member is triggered
    group_set = group_pieces(data, board)

    # registers groups and pieces into a board class instance
    board.register_data(len(group_set), group_set, data)
    # solves for group bridges
    solve_bridges(board)
    # solves for remaining groups
    solve_groups(board)
    # prints moves
    print_commands(VISITED)


# Execute order 66
if __name__ == '__main__':
    main()
