from queue import PriorityQueue
import copy
import sys
from search.moves import *
from search.group import *
from search.entities import *

# Records the lowest threshold encountered at the end of each a* iteration at a certain threshold
GLOBAL_THRESHOLD = sys.maxsize
# records moves
VISITED = []


def ida_star_control_loop(board, key, group, intersection_flag):
    """
    Controls the threshold to call ida at
    :param board: contains board data
    :param key: key of piece we are moving
    :param group: group or intersection to head towards
    :param intersection_flag: flag indiicating if we are trying to reach an intersection
    """
    global GLOBAL_THRESHOLD
    # starts out as false and returns with True when the solution is found
    found = False
    # calculates the initial f value for the initial board (purely based on heuristic)
    board.f = threshold = manhattan_heuristic(
        board, key, group, intersection_flag)
    # Initial threshold generated from heuristic
    while not found:
        found = ida_star(board, key, group, threshold, None, intersection_flag)
        threshold = GLOBAL_THRESHOLD
    return found


def ida_star(board, key, group, threshold, prev_move, intersection_flag):
    """
    Controls the threshold to call ida at
    :param board: contains board data
    :param key: key of piece we are moving
    :param group: group or intersection to head towards
    :param threshold: determines the max threshold of nodes to be explored in each iteration
    :param prev_move: records the previous move
    :param intersection_flag: flag indiicating if we are trying to reach an intersection
    """
    global GLOBAL_THRESHOLD
    global VISITED
    found = False
    # for loop for each move
    for move in MOVES:
        move_index = False
        # for loop for number of pieces to move
        for i in range(board.dict[key].count, 0, -1):
            # for loop for number steps to move
            for step in range(board.dict[key].count, 0, -1):
                # checks if move is legal
                if is_legal_move(key, scale_vector(move, step), board):
                    move_index = i
                # ensures that a piece doesn't backtrack
                if move != inverse_move[prev_move] and move_index != False and is_legal_move(key, scale_vector(move, step), board):
                    # moves a piece and records the future position of the piece
                    future_position = move_piece(
                        key, move, move_index, board, board.white_dict[key].count, step)
                    # updates the total of moves made by the board
                    board.g += move_index
                    # appends a move to the commands list
                    VISITED.append("MOVE " + str(move_index) + " from " +
                                   str(key) + " to " + str(future_position) + ".")
                    # calculates the heuristic of the board
                    heuristic = manhattan_heuristic(board,
                                                    future_position, group, intersection_flag)
                    # calculates the f function of the board
                    board.f = board.g + heuristic
                    # if the f score for the current board is above the threshold
                    # the global threshold is updated to keep track of the next lowest
                    # threshold to explore in the next iteration of the ida_star_control_loop
                    if (board.f > threshold):
                        # condition for the first threshold check when global threshold will always
                        # be lower than the f value of a board
                        if (threshold == GLOBAL_THRESHOLD):
                            GLOBAL_THRESHOLD = board.f
                        else:
                            GLOBAL_THRESHOLD = min(board.f, GLOBAL_THRESHOLD)

                    # if the f score of the current board is below the current threshold, it is explored
                    else:
                        # if a group or intersection is being investigated and the heuristic value is 0 and there are no surrounding pieces, blow up
                        if (intersection_flag == 1 and heuristic == 0 and detect_secondary_pieces(board, future_position) == True) or (heuristic == 0 and detect_secondary_pieces(board, future_position) == True):
                            # adds boom to command list
                            VISITED.append(
                                "BOOM at " + str(future_position)+".")
                            # removes boomed pieces from board
                            board.boom(future_position)
                            return VISITED
                        # calls the next round of ida_star based on the new board state
                        found = ida_star(
                            board, future_position, group, threshold, move, intersection_flag)
                        # if found is called then we return it (contains movement commands if not false)
                        if found != False:
                            return found
                    # at the end of the iteration, the board is returned to the state
                    # before the current move was made by undoing it, allowing for the
                    # exploration of other moves
                    move_piece(future_position,
                               inverse_move[move],
                               move_index,
                               board,
                               board.white_dict[future_position].count, step)
                    # removes a move command when we undo a step
                    VISITED.pop()
                    # the steps made earlier are undone
                    board.g -= move_index
    return False


def detect_secondary_pieces(board, piece):
    """
    finds out if secondary pieces will blow up in an explosion
    :param board: contains board data
    :param piece: key of piece that is exploding
    """
    # gets all pieces that will blow up
    exploded = board.simulate_boom(piece)
    result = True
    for i in exploded:
        # if there are surrounding white secondary pieces in the explosion return false
        if (board.dict[i].team == WHITE and board.dict[i].primary == False):
            result = False
            # if the exploding stack contains more than 1 piece return false
        if (board.dict[piece].count > 1):
            result = False
    return result
